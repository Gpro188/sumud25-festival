<header>
    <div class="container">
        <h1>SUMUD'25 Arts Festival - Admin Panel</h1>
        <nav>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="teams.php">Manage Teams</a></li>
                <li><a href="programs.php">Manage Programs</a></li>
                <li><a href="results.php">Update Results</a></li>
                <li><a href="gallery.php">Manage Gallery</a></li>
                <li><a href="admin_profile.php">Profile</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
</header>